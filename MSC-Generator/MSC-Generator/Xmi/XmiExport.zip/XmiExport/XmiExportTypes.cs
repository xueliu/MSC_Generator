/*
 * Erstellt mit SharpDevelop.
 * Benutzer: Administrator
 * Datum: 23.11.2007
 * Zeit: 14:29
 * 
 * Sie k�nnen diese Vorlage unter Extras > Optionen > Codeerstellung > Standardheader �ndern.
 */

using System;

namespace xmiExport
{
	/// <summary>
	/// Description of XmiExportTypes.
	/// </summary>
	public class XmiExportTypes
	{
		public const int STANDARD_XMI_EXPORT=1;
		public const int PAPYRUS_XMI_EXPORT=2;
	}
}
