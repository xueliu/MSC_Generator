/*
 * Erstellt mit SharpDevelop.
 * Benutzer: Administrator
 * Datum: 01.10.2007
 * Zeit: 10:04
 * 
 * Sie k�nnen diese Vorlage unter Extras > Optionen > Codeerstellung > Standardheader �ndern.
 */

using System;
using System.Xml;

namespace nGenerator
{
	/// <summary>
	/// Description of XmiExport.
	/// </summary>
	public class XmiExport
	{
	
		/*public static void Main(string[] args)
		{
			XmiDocumentBuilder builder=new XmiDocumentBuilder();
			XmlDocument document=builder.createXMIDocument();
			builder.createModelElement(document);
			
			System.Console.WriteLine(document.ToString());
			document.Save("C:/TestXMIExport.xmi");
		}*/
	}
}
